"""
==========================================================================
 PASSWORD STRENGTH CHECKER WITH ENCRYPTION (Mini Password Manager)
 BCA Semester 5 - Cyber Security Project
==========================================================================
 Description:
   A desktop application built with Python (Tkinter) that:
     1. Checks the strength of a password in real time.
     2. Lets the user generate strong random passwords.
     3. Encrypts passwords using Fernet (AES-128, symmetric encryption)
        before storing them in a local SQLite database (mini vault).
     4. Allows the user to decrypt and view (show/hide) stored passwords
        after authenticating with a Master Password.

 Technology Used:
   - Python 3
   - Tkinter (GUI)
   - SQLite3 (local database)
   - cryptography library (Fernet symmetric encryption + PBKDF2HMAC key
     derivation)
   - hashlib (master password hashing)
==========================================================================
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import hashlib
import os
import re
import base64
import secrets
import string
from datetime import datetime

from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vault.db")


# ==========================================================================
# DATABASE LAYER
# ==========================================================================
def init_db():
    """Create the database tables if they do not already exist."""
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        """CREATE TABLE IF NOT EXISTS master (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL
            )"""
    )
    cur.execute(
        """CREATE TABLE IF NOT EXISTS vault (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                website TEXT NOT NULL,
                username TEXT NOT NULL,
                encrypted_password TEXT NOT NULL,
                created_at TEXT NOT NULL
            )"""
    )
    conn.commit()
    conn.close()


def master_exists():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM master")
    count = cur.fetchone()[0]
    conn.close()
    return count > 0


def save_master(password_hash, salt):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO master (id, password_hash, salt) VALUES (1, ?, ?)",
        (password_hash, salt),
    )
    conn.commit()
    conn.close()


def get_master():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT password_hash, salt FROM master WHERE id = 1")
    row = cur.fetchone()
    conn.close()
    return row  # (password_hash, salt) or None


def add_vault_entry(website, username, encrypted_password):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO vault (website, username, encrypted_password, created_at) "
        "VALUES (?, ?, ?, ?)",
        (website, username, encrypted_password, datetime.now().strftime("%Y-%m-%d %H:%M")),
    )
    conn.commit()
    conn.close()


def get_vault_entries():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("SELECT id, website, username, encrypted_password, created_at FROM vault ORDER BY id DESC")
    rows = cur.fetchall()
    conn.close()
    return rows


def delete_vault_entry(entry_id):
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("DELETE FROM vault WHERE id = ?", (entry_id,))
    conn.commit()
    conn.close()


# ==========================================================================
# CRYPTOGRAPHY HELPERS
# ==========================================================================
def derive_key(master_password: str, salt: bytes) -> bytes:
    """Derive a 32-byte Fernet key from the master password using PBKDF2HMAC."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=390000,
    )
    key = base64.urlsafe_b64encode(kdf.derive(master_password.encode()))
    return key


def hash_master_password(password: str, salt: bytes) -> str:
    """One-way hash of the master password (for login verification only)."""
    return hashlib.sha256(password.encode() + salt).hexdigest()


# ==========================================================================
# PASSWORD STRENGTH CHECKER
# ==========================================================================
COMMON_PASSWORDS = {
    "password", "123456", "123456789", "qwerty", "abc123", "password1",
    "111111", "123123", "admin", "letmein", "welcome", "monkey", "login",
    "iloveyou", "12345678", "qwerty123",
}


def check_password_strength(password: str):
    """
    Returns: (strength_label, color_hex, score(0-6), list_of_feedback_tips)
    """
    if not password:
        return "—", "#7f8c8d", 0, []

    score = 0
    feedback = []

    if len(password) >= 8:
        score += 1
    else:
        feedback.append("Use at least 8 characters")

    if len(password) >= 12:
        score += 1

    if re.search(r"[A-Z]", password):
        score += 1
    else:
        feedback.append("Add an uppercase letter")

    if re.search(r"[a-z]", password):
        score += 1
    else:
        feedback.append("Add a lowercase letter")

    if re.search(r"[0-9]", password):
        score += 1
    else:
        feedback.append("Add a number")

    if re.search(r'[!@#$%^&*(),.?":{}|<>_\-+=]', password):
        score += 1
    else:
        feedback.append("Add a special character")

    if password.lower() in COMMON_PASSWORDS:
        score = 0
        feedback = ["This is a very common password — avoid it!"]

    if score <= 2:
        return "Weak", "#e74c3c", score, feedback
    elif score <= 4:
        return "Medium", "#f39c12", score, feedback
    elif score == 5:
        return "Strong", "#27ae60", score, feedback
    else:
        return "Very Strong", "#16a085", score, feedback


def generate_strong_password(length=14) -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()_+-="
    while True:
        pwd = "".join(secrets.choice(alphabet) for _ in range(length))
        # Ensure it satisfies all strength rules
        if (re.search(r"[A-Z]", pwd) and re.search(r"[a-z]", pwd)
                and re.search(r"[0-9]", pwd)
                and re.search(r'[!@#$%^&*(),.?":{}|<>_\-+=]', pwd)):
            return pwd


# ==========================================================================
# GUI - SHARED STYLE CONSTANTS
# ==========================================================================
BG_COLOR = "#1e1e2f"
CARD_COLOR = "#2a2a40"
ACCENT_COLOR = "#6c5ce7"
TEXT_COLOR = "#f5f6fa"
SUBTEXT_COLOR = "#a4a4c1"
ENTRY_BG = "#34344a"
FONT_TITLE = ("Segoe UI", 18, "bold")
FONT_NORMAL = ("Segoe UI", 11)
FONT_SMALL = ("Segoe UI", 9)


def style_entry(entry):
    entry.configure(
        bg=ENTRY_BG, fg=TEXT_COLOR, insertbackground=TEXT_COLOR,
        relief="flat", font=FONT_NORMAL, highlightthickness=1,
        highlightbackground="#45456a", highlightcolor=ACCENT_COLOR,
    )


def style_button(btn, primary=True):
    if primary:
        btn.configure(bg=ACCENT_COLOR, fg="white", activebackground="#5849c2",
                       activeforeground="white", relief="flat", font=FONT_NORMAL,
                       cursor="hand2", bd=0, padx=10, pady=6)
    else:
        btn.configure(bg=ENTRY_BG, fg=TEXT_COLOR, activebackground="#45456a",
                       activeforeground="white", relief="flat", font=FONT_NORMAL,
                       cursor="hand2", bd=0, padx=10, pady=6)


# ==========================================================================
# SETUP / LOGIN SCREENS
# ==========================================================================
class AuthWindow:
    """Handles master password setup (first run) or login (subsequent runs)."""

    def __init__(self, root, on_success):
        self.root = root
        self.on_success = on_success
        self.is_new_user = not master_exists()

        self.frame = tk.Frame(root, bg=BG_COLOR)
        self.frame.pack(fill="both", expand=True)

        self._build_ui()

    def _build_ui(self):
        wrapper = tk.Frame(self.frame, bg=BG_COLOR)
        wrapper.place(relx=0.5, rely=0.5, anchor="center")

        icon = tk.Label(wrapper, text="🔒", font=("Segoe UI", 40), bg=BG_COLOR, fg=ACCENT_COLOR)
        icon.pack(pady=(0, 10))

        title_text = "Create Master Password" if self.is_new_user else "Welcome Back"
        title = tk.Label(wrapper, text=title_text, font=FONT_TITLE, bg=BG_COLOR, fg=TEXT_COLOR)
        title.pack(pady=(0, 4))

        sub_text = ("This password will protect your entire vault.\n"
                    "Remember it — it cannot be recovered.") if self.is_new_user else \
                   "Enter your master password to unlock your vault."
        sub = tk.Label(wrapper, text=sub_text, font=FONT_SMALL, bg=BG_COLOR, fg=SUBTEXT_COLOR, justify="center")
        sub.pack(pady=(0, 20))

        self.pwd_entry = tk.Entry(wrapper, show="●", width=30, justify="center")
        style_entry(self.pwd_entry)
        self.pwd_entry.pack(ipady=8, pady=6)
        self.pwd_entry.focus()

        if self.is_new_user:
            self.confirm_entry = tk.Entry(wrapper, show="●", width=30, justify="center")
            style_entry(self.confirm_entry)
            self.confirm_entry.pack(ipady=8, pady=6)

        self.error_label = tk.Label(wrapper, text="", font=FONT_SMALL, bg=BG_COLOR, fg="#e74c3c")
        self.error_label.pack(pady=(6, 0))

        btn_text = "Create Vault" if self.is_new_user else "Unlock Vault"
        btn = tk.Button(wrapper, text=btn_text, command=self._submit)
        style_button(btn)
        btn.pack(pady=(16, 0), ipadx=10)

        self.root.bind("<Return>", lambda e: self._submit())

    def _submit(self):
        password = self.pwd_entry.get()

        if self.is_new_user:
            confirm = self.confirm_entry.get()
            if len(password) < 4:
                self.error_label.config(text="Password must be at least 4 characters")
                return
            if password != confirm:
                self.error_label.config(text="Passwords do not match")
                return
            salt = os.urandom(16)
            pwd_hash = hash_master_password(password, salt)
            save_master(pwd_hash, base64.b64encode(salt).decode())
            key = derive_key(password, salt)
            self._proceed(key)
        else:
            row = get_master()
            if row is None:
                self.error_label.config(text="No master password found.")
                return
            stored_hash, salt_b64 = row
            salt = base64.b64decode(salt_b64)
            if hash_master_password(password, salt) != stored_hash:
                self.error_label.config(text="Incorrect master password")
                return
            key = derive_key(password, salt)
            self._proceed(key)

    def _proceed(self, key):
        self.root.unbind("<Return>")
        self.frame.destroy()
        self.on_success(key)


# ==========================================================================
# MAIN APPLICATION (after login)
# ==========================================================================
class MainApp:
    def __init__(self, root, fernet_key):
        self.root = root
        self.fernet = Fernet(fernet_key)
        self.visible_password_id = None  # track which vault row is currently shown decrypted

        self.frame = tk.Frame(root, bg=BG_COLOR)
        self.frame.pack(fill="both", expand=True)

        self._build_header()
        self._build_tabs()

    # ---------------- HEADER ----------------
    def _build_header(self):
        header = tk.Frame(self.frame, bg=BG_COLOR)
        header.pack(fill="x", padx=20, pady=(16, 0))

        title = tk.Label(header, text="🔐 SecureVault", font=FONT_TITLE, bg=BG_COLOR, fg=TEXT_COLOR)
        title.pack(side="left")

        sub = tk.Label(header, text="Password Strength Checker & Encrypted Vault",
                        font=FONT_SMALL, bg=BG_COLOR, fg=SUBTEXT_COLOR)
        sub.pack(side="left", padx=(10, 0), pady=(8, 0))

    # ---------------- TABS ----------------
    def _build_tabs(self):
        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook", background=BG_COLOR, borderwidth=0)
        style.configure("TNotebook.Tab", background=CARD_COLOR, foreground=TEXT_COLOR,
                         padding=[16, 10], font=FONT_NORMAL)
        style.map("TNotebook.Tab", background=[("selected", ACCENT_COLOR)],
                  foreground=[("selected", "white")])

        self.notebook = ttk.Notebook(self.frame)
        self.notebook.pack(fill="both", expand=True, padx=20, pady=20)

        self.tab_checker = tk.Frame(self.notebook, bg=BG_COLOR)
        self.tab_add = tk.Frame(self.notebook, bg=BG_COLOR)
        self.tab_vault = tk.Frame(self.notebook, bg=BG_COLOR)

        self.notebook.add(self.tab_checker, text="  Strength Checker  ")
        self.notebook.add(self.tab_add, text="  Add Password  ")
        self.notebook.add(self.tab_vault, text="  My Vault  ")

        self._build_checker_tab()
        self._build_add_tab()
        self._build_vault_tab()
        self.notebook.bind("<<NotebookTabChanged>>", lambda e: self._refresh_vault())

    # ---------------- TAB 1: STRENGTH CHECKER ----------------
    def _build_checker_tab(self):
        card = tk.Frame(self.tab_checker, bg=CARD_COLOR)
        card.pack(fill="x", pady=10, padx=4)

        lbl = tk.Label(card, text="Type a password to check its strength", font=FONT_NORMAL,
                        bg=CARD_COLOR, fg=TEXT_COLOR)
        lbl.pack(anchor="w", padx=20, pady=(20, 6))

        entry_row = tk.Frame(card, bg=CARD_COLOR)
        entry_row.pack(fill="x", padx=20)

        self.check_var = tk.StringVar()
        self.check_entry = tk.Entry(entry_row, textvariable=self.check_var, show="●", width=34)
        style_entry(self.check_entry)
        self.check_entry.pack(side="left", ipady=8, fill="x", expand=True)
        self.check_var.trace_add("write", lambda *a: self._update_strength_display())

        self.show_var = tk.BooleanVar(value=False)
        toggle_btn = tk.Button(entry_row, text="👁", width=3, command=self._toggle_check_visibility)
        style_button(toggle_btn, primary=False)
        toggle_btn.pack(side="left", padx=(8, 0))

        gen_btn = tk.Button(card, text="Generate Strong Password",
                             command=self._generate_for_checker)
        style_button(gen_btn, primary=False)
        gen_btn.pack(anchor="w", padx=20, pady=(10, 0))

        # Strength meter
        self.meter_canvas = tk.Canvas(card, height=10, bg=ENTRY_BG, highlightthickness=0)
        self.meter_canvas.pack(fill="x", padx=20, pady=(18, 4))

        self.strength_label = tk.Label(card, text="Strength: —", font=("Segoe UI", 12, "bold"),
                                        bg=CARD_COLOR, fg=SUBTEXT_COLOR)
        self.strength_label.pack(anchor="w", padx=20)

        self.feedback_label = tk.Label(card, text="", font=FONT_SMALL, bg=CARD_COLOR,
                                        fg=SUBTEXT_COLOR, justify="left")
        self.feedback_label.pack(anchor="w", padx=20, pady=(6, 20))

    def _toggle_check_visibility(self):
        self.show_var.set(not self.show_var.get())
        self.check_entry.config(show="" if self.show_var.get() else "●")

    def _generate_for_checker(self):
        pwd = generate_strong_password()
        self.check_var.set(pwd)
        self.show_var.set(True)
        self.check_entry.config(show="")

    def _update_strength_display(self):
        password = self.check_var.get()
        strength, color, score, feedback = check_password_strength(password)
        self.strength_label.config(text=f"Strength: {strength}", fg=color)
        self.feedback_label.config(text=("Tips: " + "; ".join(feedback)) if feedback else "Looks good!")

        self.meter_canvas.delete("all")
        width = self.meter_canvas.winfo_width() or 400
        pct = min(score / 6, 1.0)
        self.meter_canvas.create_rectangle(0, 0, width, 10, fill=ENTRY_BG, outline="")
        self.meter_canvas.create_rectangle(0, 0, width * pct, 10, fill=color, outline="")

    # ---------------- TAB 2: ADD PASSWORD ----------------
    def _build_add_tab(self):
        card = tk.Frame(self.tab_add, bg=CARD_COLOR)
        card.pack(fill="x", pady=10, padx=4)

        def labeled_entry(parent, label_text, show=None):
            tk.Label(parent, text=label_text, font=FONT_SMALL, bg=CARD_COLOR,
                      fg=SUBTEXT_COLOR).pack(anchor="w", padx=20, pady=(14, 2))
            e = tk.Entry(parent, show=show, width=40)
            style_entry(e)
            e.pack(padx=20, ipady=8, fill="x")
            return e

        self.add_website = labeled_entry(card, "Website / App Name")
        self.add_username = labeled_entry(card, "Username / Email")

        tk.Label(card, text="Password", font=FONT_SMALL, bg=CARD_COLOR,
                  fg=SUBTEXT_COLOR).pack(anchor="w", padx=20, pady=(14, 2))
        pwd_row = tk.Frame(card, bg=CARD_COLOR)
        pwd_row.pack(fill="x", padx=20)
        self.add_password = tk.Entry(pwd_row, show="●")
        style_entry(self.add_password)
        self.add_password.pack(side="left", ipady=8, fill="x", expand=True)
        self.add_password.bind("<KeyRelease>", lambda e: self._update_add_strength())

        gen_btn = tk.Button(pwd_row, text="🎲", width=3,
                             command=self._generate_for_add)
        style_button(gen_btn, primary=False)
        gen_btn.pack(side="left", padx=(8, 0))

        self.add_strength_label = tk.Label(card, text="Strength: —", font=FONT_SMALL,
                                            bg=CARD_COLOR, fg=SUBTEXT_COLOR)
        self.add_strength_label.pack(anchor="w", padx=20, pady=(8, 0))

        save_btn = tk.Button(card, text="🔒  Encrypt & Save to Vault", command=self._save_entry)
        style_button(save_btn)
        save_btn.pack(padx=20, pady=20, anchor="w")

    def _generate_for_add(self):
        pwd = generate_strong_password()
        self.add_password.delete(0, "end")
        self.add_password.insert(0, pwd)
        self.add_password.config(show="")
        self._update_add_strength()

    def _update_add_strength(self):
        strength, color, score, _ = check_password_strength(self.add_password.get())
        self.add_strength_label.config(text=f"Strength: {strength}", fg=color)

    def _save_entry(self):
        website = self.add_website.get().strip()
        username = self.add_username.get().strip()
        password = self.add_password.get()

        if not website or not username or not password:
            messagebox.showwarning("Missing Info", "Please fill in all fields.")
            return

        encrypted = self.fernet.encrypt(password.encode()).decode()
        add_vault_entry(website, username, encrypted)

        self.add_website.delete(0, "end")
        self.add_username.delete(0, "end")
        self.add_password.delete(0, "end")
        self.add_strength_label.config(text="Strength: —", fg=SUBTEXT_COLOR)

        messagebox.showinfo("Saved", f"Password for '{website}' encrypted and saved to vault.")
        self._refresh_vault()

    # ---------------- TAB 3: VAULT ----------------
    def _build_vault_tab(self):
        card = tk.Frame(self.tab_vault, bg=CARD_COLOR)
        card.pack(fill="both", expand=True, pady=10, padx=4)

        style = ttk.Style()
        style.configure("Vault.Treeview", background=ENTRY_BG, fieldbackground=ENTRY_BG,
                         foreground=TEXT_COLOR, rowheight=30, font=FONT_NORMAL, borderwidth=0)
        style.configure("Vault.Treeview.Heading", background=CARD_COLOR, foreground=TEXT_COLOR,
                         font=("Segoe UI", 10, "bold"))
        style.map("Vault.Treeview", background=[("selected", ACCENT_COLOR)])

        columns = ("website", "username", "password", "created")
        self.tree = ttk.Treeview(card, columns=columns, show="headings", style="Vault.Treeview", height=10)
        self.tree.heading("website", text="Website / App")
        self.tree.heading("username", text="Username")
        self.tree.heading("password", text="Password")
        self.tree.heading("created", text="Saved On")
        self.tree.column("website", width=160)
        self.tree.column("username", width=160)
        self.tree.column("password", width=180)
        self.tree.column("created", width=120)
        self.tree.pack(fill="both", expand=True, padx=20, pady=(20, 10))

        btn_row = tk.Frame(card, bg=CARD_COLOR)
        btn_row.pack(fill="x", padx=20, pady=(0, 20))

        show_btn = tk.Button(btn_row, text="👁 Show / Hide Password", command=self._toggle_show_selected)
        style_button(show_btn, primary=False)
        show_btn.pack(side="left")

        del_btn = tk.Button(btn_row, text="🗑 Delete Entry", command=self._delete_selected)
        style_button(del_btn, primary=False)
        del_btn.pack(side="left", padx=(10, 0))

        self._refresh_vault()

    def _refresh_vault(self):
        if not hasattr(self, "tree"):
            return
        for row in self.tree.get_children():
            self.tree.delete(row)
        for entry_id, website, username, enc_pwd, created in get_vault_entries():
            display_pwd = "••••••••"
            if entry_id == self.visible_password_id:
                try:
                    display_pwd = self.fernet.decrypt(enc_pwd.encode()).decode()
                except Exception:
                    display_pwd = "[error decrypting]"
            self.tree.insert("", "end", iid=str(entry_id),
                              values=(website, username, display_pwd, created))

    def _toggle_show_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select an entry", "Please select a row first.")
            return
        entry_id = int(selected[0])
        if self.visible_password_id == entry_id:
            self.visible_password_id = None  # hide again
        else:
            self.visible_password_id = entry_id
        self._refresh_vault()

    def _delete_selected(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select an entry", "Please select a row first.")
            return
        entry_id = int(selected[0])
        if messagebox.askyesno("Confirm Delete", "Delete this saved password permanently?"):
            delete_vault_entry(entry_id)
            self.visible_password_id = None
            self._refresh_vault()


# ==========================================================================
# APP ENTRY POINT
# ==========================================================================
def main():
    init_db()
    root = tk.Tk()
    root.title("SecureVault - Password Strength Checker with Encryption")
    root.geometry("640x560")
    root.minsize(560, 480)
    root.configure(bg=BG_COLOR)

    def start_main_app(fernet_key):
        MainApp(root, fernet_key)

    AuthWindow(root, on_success=start_main_app)
    root.mainloop()


if __name__ == "__main__":
    main()
