# SecureVault — Password Strength Checker with Encryption

A BCA Semester 5 Cyber Security mini project. A Python desktop GUI application
that checks password strength in real time and stores passwords safely in an
encrypted local vault.

## Features
- Real-time password strength meter (Weak / Medium / Strong / Very Strong)
- Detects common/weak passwords
- Strong random password generator
- Master-password-protected vault (your passwords never leave your computer)
- Passwords encrypted with Fernet (AES-128) before being stored
- Show/Hide (decrypt) saved passwords on demand
- Delete saved entries

## How it works (short version)
1. On first run, you create a **Master Password**. It is hashed (SHA-256 +
   random salt) and stored — never the raw password.
2. The same master password + salt is run through **PBKDF2HMAC** to derive a
   32-byte encryption key (this happens only in memory, every time you log in).
3. That key is used to create a **Fernet** cipher, which encrypts every
   password before it is written to the local **SQLite** database
   (`vault.db`) and decrypts it again only when you click "Show Password".

## Requirements
- Python 3.8+
- Tkinter (usually bundled with Python; on Linux: `sudo apt install python3-tk`)

## Setup
```bash
pip install -r requirements.txt
```

## Run
```bash
python main.py
```

## Project Structure
```
password_manager/
├── main.py            # Full application (GUI + logic + DB + crypto)
├── requirements.txt   # Python dependencies
├── vault.db           # Created automatically on first run (local database)
└── README.md
```

## Notes for viva / submission
- Encryption algorithm: **Fernet** (symmetric, built on AES-128-CBC + HMAC for
  integrity) from the `cryptography` library.
- Key derivation: **PBKDF2-HMAC-SHA256** with 390,000 iterations, which makes
  brute-forcing the master password computationally expensive.
- The master password itself is **never stored** — only its salted hash, used
  purely to verify login.
